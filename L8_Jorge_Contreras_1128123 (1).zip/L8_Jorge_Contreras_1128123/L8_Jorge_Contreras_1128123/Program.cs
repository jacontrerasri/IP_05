﻿using System;

namespace ConversorQuetzales
{
    class Program
    {
        static void Main()
        {
            string nombre, carne;

            Console.Write("Ingrese su nombre: ");
            nombre = Console.ReadLine();
            Console.Write("Ingrese su carne: ");
            carne = Console.ReadLine();
            

           
            Console.Write("Ingrese la cantidad en quetzales (entre 0 y 999.99): ");

            if (double.TryParse(Console.ReadLine(), out double cantidad))
            {
                if (cantidad >= 0 && cantidad <= 999.99)
                {
                    
                    int billetes100 = (int)(cantidad / 100);
                    cantidad %= 100;

                    int billetes50 = (int)(cantidad / 50);
                    cantidad %= 50;

                    int billetes20 = (int)(cantidad / 20);
                    cantidad %= 20;

                    int billetes10 = (int)(cantidad / 10);
                    cantidad %= 10;

                    int billetes5 = (int)(cantidad / 5);
                    cantidad %= 5;

                    int monedas1 = (int)cantidad;
                    cantidad %= 1;

                    int monedas25Centavos = (int)(cantidad / 0.25);
                    cantidad %= 0.25;

                    int monedas1Centavo = (int)(cantidad / 0.01);

                    
                    Console.WriteLine("Equivalencia en billetes y monedas: ");
                    Console.WriteLine("Billetes de 100 quetzales: " + billetes100);
                    Console.WriteLine("Billetes de 50 quetzales: " + billetes50);
                    Console.WriteLine("Billetes de 20 quetzales: " + billetes20);
                    Console.WriteLine("Billetes de 10 quetzales: " + billetes10);
                    Console.WriteLine("Billetes de 5 quetzales: "  + billetes5);
                    Console.WriteLine("Monedas de 1 quetzal: " + monedas1);
                    Console.WriteLine("Monedas de 25 centavos: " + monedas25Centavos);
                    Console.WriteLine("Monedas de 1 centavo: " + monedas1Centavo);
                }
                else
                {
                    Console.WriteLine("La cantidad ingresada debe estar entre 0 y 999.99 quetzales.");
                }
            }
            else
            {
                Console.WriteLine("Cantidad ingresada no valida.");
            }
        }
    }
}
