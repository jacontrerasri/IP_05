﻿using System;

namespace Ejercicios
{
    class Program
    {
        static void Main(string[] args)
        {
            
            Console.WriteLine("Ejercicio 1");
            Console.Write("Número Entero: ");

            string input = Console.ReadLine();

            if (int.TryParse(input, out int numero))
            {
                if (numero > 0)
                {
                    Console.WriteLine("RESULTADO: El numero es positivo.");
                }
                else if (numero < 0)
                {
                    Console.WriteLine("RESULTADO: El numero es negativo.");
                }
                else
                {
                    Console.WriteLine("RESULTADO: El numero es cero.");
                }
            }
            else
            {
                Console.WriteLine("Error: Debe ingresar un numero entero valido.");
            }

            
            Console.WriteLine("Ejercicio 2");
            Console.Write("Ingrese un numero del 1 al 7 para conocer el di de la semana: ");

            input = Console.ReadLine();

            if (int.TryParse(input, out int dia))
            {
                if (dia >= 1 && dia <= 7)
                {
                    string nombreDia = "";
                    switch (dia)
                    {
                        case 1:
                            nombreDia = "lunes";
                            break;
                        case 2:
                            nombreDia = "martes";
                            break;
                        case 3:
                            nombreDia = "miercoles";
                            break;
                        case 4:
                            nombreDia = "jueves";
                            break;
                        case 5:
                            nombreDia = "viernes";
                            break;
                        case 6:
                            nombreDia = "sabado";
                            break;
                        case 7:
                            nombreDia = "domingo";
                            break;
                    }
                    Console.WriteLine("Dia: " + nombreDia);
                }
                else
                {
                    Console.WriteLine("Error: El numero a ingresar debe estar contenido entre 1 y 7.");
                }
            }
            else
            {
                Console.WriteLine("Error: Debe ingresar un numero entero valido.");
            }
        }
    }
}
