﻿using System;

class Program
{
    static void Main()
    {
        Console.WriteLine("Ejercicio 1: Operaciones aritmeticas");
        Console.WriteLine();

        int numero1, numero2, suma = 0, resta = 0, multiplicacion = 0, division = 0;
        Console.WriteLine();

        Console.Write("Ingrese el primer número: ");
        numero1 = int.Parse(Console.ReadLine());
        Console.WriteLine();

        Console.Write("Ingrese el segundo número: ");
        numero2 = int.Parse(Console.ReadLine());
        Console.WriteLine();

        suma = numero1 + numero2;
        Console.WriteLine();
        resta = numero1 - numero2;
        Console.WriteLine();
        multiplicacion = numero1 * numero2;
        Console.WriteLine();
        division = numero1 / numero2;
        Console.WriteLine();

        Console.WriteLine(numero1 + " + " + numero2 + " = " + suma);
        Console.WriteLine(numero1 + " * " + numero2 + " = " + multiplicacion);
        Console.WriteLine(numero1 + " - " + numero2 + " = " + resta);
        Console.WriteLine(numero1 + " / " + numero2 + " = " + division);
        Console.WriteLine();

        Console.WriteLine("Ejercicio 2: Operaciones booleanas");

        bool mayorque = numero1 > numero2;
        bool menorque = numero1 < numero2;
        bool igual = numero1 == numero2;
        Console.WriteLine();

        Console.WriteLine(numero1 + " > " + numero2 + " = " + mayorque);     
        Console.WriteLine(numero1 + " < " + numero2 + " = " + menorque);
        Console.WriteLine(numero1 + " == " + numero2 + " = " + igual);
        Console.WriteLine();

        Console.WriteLine("Ejercicio 3: Jerarquía de operaciones");
        Console.WriteLine();

        Console.Write("Ingrese el valor de a: ");
        double a = Convert.ToDouble(Console.ReadLine());
        Console.WriteLine();

        Console.Write("Ingrese el valor de b: ");
        double b = Convert.ToDouble(Console.ReadLine());
        Console.WriteLine();

        Console.Write("Ingrese el valor de c: ");
        double c = Convert.ToDouble(Console.ReadLine());
        Console.WriteLine();

        double ecuacion1 = a * b + c;
        double ecuacion2 = a * (b + c);
        double ecuacion3 = a / (b * c);
        double ecuacion4 = (3 * a + 2 * b) / (c * c);
        Console.WriteLine();

        Console.WriteLine("a * b + c = " + ecuacion1);
        Console.WriteLine("a * (b + c) = " + ecuacion2);
        Console.WriteLine("a / (b * c) = " + ecuacion3);
        Console.WriteLine("(3a + 2b) / (c^2) = " + ecuacion4);
        Console.WriteLine();

        Console.WriteLine();
        Console.ReadKey();
    }
}

