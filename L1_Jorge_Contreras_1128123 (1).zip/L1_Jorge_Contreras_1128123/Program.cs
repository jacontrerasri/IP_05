﻿class project
{
    static void Main(string[] args)
    {
        Console.WriteLine("Ingrese su nombre");
        string Nombre = Console.ReadLine();

        Console.WriteLine("Buenas");
        Console.WriteLine("Soy" + Nombre);

        /*Ejemplo de comentario en varias lineas 
        aaaaaaaaaaaaaaaaaaa*/

        Console.WriteLine("Buenas");
        Console.WriteLine("Soy" + Nombre);
        Console.ReadKey();

    }






}