﻿class project
{
    static void Main(string[] args)
    {
        
        string sNombre, sEdad, sCarrera, sCarne;

        //Inegreso de nombre
        Console.WriteLine("Ingrese nombre: ");
        sNombre = Console.ReadLine();

        //Inegreso de edad
        Console.WriteLine("Ingrese edad: ");
        sEdad = Console.ReadLine();

        //Ingreso de carrera
        Console.WriteLine("Ingrese carrera: ");
        sCarrera = Console.ReadLine();

        //Ingreso de carne
        Console.WriteLine("Ingrese carne: ");
        sCarne = Console.ReadLine();

        Console.WriteLine("Mi segundo programa");
        Console.WriteLine();
        Console.WriteLine("Nombre: " + sNombre);
        Console.WriteLine();
        Console.WriteLine("Nombre: " + sEdad);
        Console.WriteLine();
        Console.WriteLine("Nombre: " + sCarrera);
        Console.WriteLine();
        Console.WriteLine("Nombre: " + sCarne);

        Console.Write("Soy " + sNombre + " tengo " + sEdad + " años y estudio la cerrera de " + sCarrera);
        Console.Write(", Mi numero de carne es " + sCarne);
        Console.ReadKey();

    }






}