﻿using System;

class Program
{
    static void Main()
    {
        double Compra;
        double descuento = 0.0;
        double Total;

        Console.Write("Ingrese el monto de la compra en quetzales: ");
        if (double.TryParse(Console.ReadLine(), out Compra))
        {
            if (Compra < 400)
            {
                
                descuento = 0.0;
            }
            else if (Compra >= 400 && Compra <= 1000)
            {
                
                descuento = 0.07;
            }
            else if (Compra > 1000 && Compra <= 5000)
            {
                
                descuento = 0.10;
            }
            else if (Compra > 5000 && Compra <= 15000)
            {
                
                descuento = 0.15;
            }
            else
            {
                
                descuento = 0.25;
            }

           
            Console.Write("¿Tiene un código de descuento? (S o N): ");
            string Codigodescuento = Console.ReadLine().ToUpper();

            if (Codigodescuento == "S")
            {
                
                descuento += 0.05;
            }

            
            Total = Compra - (Compra * descuento);

            Console.WriteLine("Monto a pagar con descuento: Q{0:N2}", Total);
        }
        else
        {
            Console.WriteLine("Error: Ingrese un monto válido.");
        }
    }
}
