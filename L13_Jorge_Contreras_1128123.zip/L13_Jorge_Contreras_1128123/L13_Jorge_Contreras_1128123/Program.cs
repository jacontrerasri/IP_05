﻿class Program
{

    //public static double dCantidad1, dCantidad2, dCantidad3;
    //public static string sDenominacion1, sDenominacion2, sDenominacion3;
    public static int contador = 0;
    public static double[] aCantidad = new double[3];
    public static string[] aDenominacion = new string[3];

    public static void Main(string[] args)
    {
        string[] aSCantidad = new string[3];

        Console.WriteLine("Programa actividad 1 - Semana 9");

        // cantidad 1
        Console.WriteLine("Ingrese cantidad de dinero # 1");
        aSCantidad[0] = Console.ReadLine();

        while (!double.TryParse(aSCantidad[0], out aCantidad[0]))
        {
            Console.WriteLine("Ingrese cantidad 1 en formato correcto, ejemplo: 0.00");
            aSCantidad[0] = Console.ReadLine();
        }

        Console.WriteLine("Ingrese denominación de cantidad 1, Ejemplo: USD ó GTQ ");
        aDenominacion[0] = Console.ReadLine();
        //llamada a metodo tipo funcion que devuelve valor en quetzales
        aCantidad[0] = calcular(aCantidad[0], aDenominacion[0]);


        // cantidad 2
        Console.WriteLine("Ingrese cantidad de dinero # 2");
        aSCantidad[1] = Console.ReadLine();

        while (!double.TryParse(aSCantidad[1], out aCantidad[1]))
        {
            Console.WriteLine("Ingrese cantidad 2 en formato correcto, ejemplo: 0.00");
            aSCantidad[1] = Console.ReadLine();
        }
        Console.WriteLine("Ingrese denominación de cantidad 2, Ejemplo: USD ó GTQ ");
        aDenominacion[1] = Console.ReadLine();
        aCantidad[1] = calcular(aCantidad[1], aDenominacion[1]);


        // cantidad 3
        Console.WriteLine("Ingrese cantidad de dinero # 3");
        aSCantidad[2] = Console.ReadLine();

        while (!double.TryParse(aSCantidad[2], out aCantidad[2]))
        {
            Console.WriteLine("Ingrese cantidad 3 en formato correcto, ejemplo: 0.00");
            aSCantidad[2] = Console.ReadLine();
        }
        Console.WriteLine("Ingrese denominación de cantidad 2, Ejemplo: USD ó GTQ ");
        aDenominacion[2] = Console.ReadLine();
        aCantidad[2] = calcular(aCantidad[2], aDenominacion[2]);

        mostrarResultado();

    }

    //funcion que devuelve cantidad en quetzales
    public static double calcular(double cantidad, string denominacion)
    {
        if (denominacion == "USD")
        {
            cantidad = cantidad * 7.83;
        }
        return cantidad;
    }

    public static void mostrarResultado()
    {
        double dCantidad1, dCantidad2, dCantidad3;

        dCantidad1 = aCantidad[0];
        dCantidad2 = aCantidad[1];
        dCantidad3 = aCantidad[2];
        double mayor, medio, menor;
        //mayor
        if (dCantidad1 > dCantidad2 && dCantidad1 > dCantidad3)
        {
            mayor = dCantidad1;
        }
        else if (dCantidad2 > dCantidad1 && dCantidad2 > dCantidad3)
        {
            mayor = dCantidad2;
        }
        else
        {
            mayor = dCantidad3;
        }

        //menor
        if (dCantidad1 < dCantidad2 && dCantidad1 < dCantidad3)
        {
            menor = dCantidad1;
        }
        else if (dCantidad2 < dCantidad1 && dCantidad2 < dCantidad3)
        {
            menor = dCantidad2;
        }
        else
        {
            menor = dCantidad3;
        }

        //medio
        if (dCantidad1 > menor && dCantidad1 < mayor)
        {
            medio = dCantidad1;
        }
        else if (dCantidad2 > menor && dCantidad2 < mayor)
        {
            medio = dCantidad2;
        }
        else
        {
            medio = dCantidad3;
        }

        string resultado = $"{mayor} GTQ \n {medio} GTQ \n {menor} GTQ ";
        Console.WriteLine("Resultado:");
        Console.WriteLine(resultado);

        Console.WriteLine("Ejemplo de barrido de arreglo:");
        for (int x = 0; x < 3; x++)
        {
            Console.WriteLine(aCantidad[x]);
        }
        Console.ReadKey();

    }
}