﻿using System;

class Program
{
    static void Main()
    {
        double[] cantidades = new double[3];
        string[] monedas = new string[3];
        double cambio = 7.83;

        for (int i = 0; i < 3; i++)
        {
            Console.Write("Ingrese la cantidad {0}: ", i + 1);
            cantidades[i] = Convert.ToDouble(Console.ReadLine());

            Console.Write("Ingrese la moneda (USD o GTQ) para la cantidad {0}: ", i + 1);
            monedas[i] = Console.ReadLine().ToUpper();
        }

        for (int i = 0; i < 2; i++)
        {
            for (int j = 0; j < 2 - i; j++)
            {
                if (cantidades[j] > cantidades[j + 1])
                {

                    double Cantidad = cantidades[j];
                    cantidades[j] = cantidades[j + 1];
                    cantidades[j + 1] = Cantidad;


                    string Moneda = monedas[j];
                    monedas[j] = monedas[j + 1];
                    monedas[j + 1] = Moneda;
                }
            }
        }

        Console.WriteLine("Cantidades ordenadas en quetzales: ");

        for (int i = 0; i < 3; i++)
        {
            double cantidadQ = monedas[i] == "USD" ? cantidades[i] * cambio : cantidades[i];
            Console.WriteLine("{0} {1} = {2} GTQ", cantidades[i], monedas[i], cantidadQ);
        }
    }
}
