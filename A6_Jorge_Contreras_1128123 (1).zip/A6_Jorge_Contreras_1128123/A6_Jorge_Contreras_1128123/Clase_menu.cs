﻿using System.Linq.Expressions;

class Clase_menu
{
    static void Main(string[] args)
    {

        Console.WriteLine("Tiempos de Produccion");
        Console.WriteLine();
        Console.WriteLine("Sellecione opcion");
        Console.WriteLine();
        Console.WriteLine("Menu de bebidas");
        Console.WriteLine("1. Naturales");
        Console.WriteLine("2. Alcoholicas");
        Console.WriteLine("3. Energizantes");
        Console.WriteLine("4. Gaseosas");
        Console.WriteLine("5. Agua pura");

        string opcion = Console.ReadLine();
        switch (opcion)
        {
            case "1":
                Console.WriteLine("Selecciono opcion: " + opcion + "Naturales");
                break;
            case "2":
                Console.WriteLine("Selecciono opcion: " + opcion + "Alcoholicas");
                break;
            case "3":
                Console.WriteLine("Selecciono opcion: " + opcion + "Energizantes");
                break;
            case "4":
                Console.WriteLine("Selecciono opcion: " + opcion + "Gaseosas");
                break;
            case "5":
                Console.WriteLine("Selecciono opcion: " + opcion + "Agua pura");
                break;
            
            default:
                Console.WriteLine("Selecciono una opcion invalida");
                break;
        }
        
        Console.ReadKey();


















    }
}
        


